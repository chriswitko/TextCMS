<meta charset="utf-8">
<title><?php echo $config['app']['title']?><?php echo @$page_title?' - '.$page_title:''; ?></title>
<meta name="description" content=""/>

<meta name="viewport" content="width=device-width,initial-scale=1">

<link rel="shortcut icon" href="favicon.ico">

<!--[if lt IE 9]>
  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<link href="/css/bootstrap.css?<?php echo $css_version; ?>" rel="stylesheet">
<link href="/css/master.css?<?php echo $css_version; ?>" rel="stylesheet">
