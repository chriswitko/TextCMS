<?php
include 'init.php';


// $csv = new parseCSV();
// $header = array('firstname', 'lastname', 'email');
// $out = $csv->save("{$config['storage']['db']}/{$config['pages']['file']}", false, false, $header);
// if($out) {
// 	echo "Created.";
// } else {
// 	echo "Not Created.";
// }

// $csv = new parseCSV();
// $data = array('John', 'Doe', 'john@doe.com');
// $out = $csv->save("{$config['storage']['db']}/{$config['pages']['file']}", array($data), true, array($header));
// if($out) {
// 	echo "Saved.";
// } else {
// 	echo "Not Saved.";
// }
// 

// $csv = new parseCSV();
// // $csv->sort_by = 'firstname';
// $csv->parse("{$config['storage']['db']}/{$config['pages']['file']}");
// # "4" is the value of the "id" column of the CSV row
// print_r($csv->data[0]);
// $csv->data[0] = array('firstname' => 'John Adamo', 'lastname' => 'Doe', 'email' => 'john@doe.com');
// print_r($csv->data[0]);
// if($csv->save("{$config['storage']['db']}/{$config['pages']['file']}")) {
// 	echo "Updated.";
// } else {
// 	echo "Not Updated.";
// }

?>