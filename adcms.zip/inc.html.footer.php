<footer style="float:left;width:100%;margin-top:10px;">
	<p>
		Copyright &copy;2012<?php echo date("Y")!='2012'?'-'.date("Y"):''; ?> · <a target="_blank" href="http://chriswitko.com">Chris Witko</a> · <a class="" href="/cms">Panel</a>
	</p>
</footer>
